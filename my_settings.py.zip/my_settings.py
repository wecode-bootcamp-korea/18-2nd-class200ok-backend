#AWS RDS
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME' : 'class200ok_third',
        'USER' : 'root',
        'PASSWORD' : 'ABzmffotmdlqordhzp',
        'HOST' : 'wecode.cakn0h8vyyyk.ap-northeast-2.rds.amazonaws.com',
        'PORT' : '3306',
    }
}

#SECRET KEY
SECRET_KEY = '5wyc*miv32o2*ttw#3nyv#3a&z5^@+)k%#i@&zdnb^&0ne$ai-'

# #AWS S3
AWS_ACCESS_KEY_ID = 'AKIAXPXNKBIULF42RGZD'
AWS_SECRET_ACCESS_KEY = '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'
AWS_STORAGE_BUCKET_NAME = 'class2oo0k'
